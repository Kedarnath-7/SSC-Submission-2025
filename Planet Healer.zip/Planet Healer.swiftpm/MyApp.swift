import SwiftUI

@main
struct PlanetHealer: App {
    var body: some Scene {
        WindowGroup {
            SpriteKitView()
        }
    }
}
